package gcu.mpd.bgsdatastarter.S1511581;
//Seamus Robinson S1511581
public class itemClass {

    private String title;
    private String description;
    private String link;
    private String pubDate;
    private String category;
    private String geolat;
    private String geolong;

    public itemClass(){
        title ="";
        description="";
        link="";
        pubDate="";
        category="";
        geolat="";
        geolong="";
    }
    public itemClass(String atitle,String adescription, String apubDate, String ageolat, String ageolong){
        title=atitle;
        description=adescription;
        pubDate=apubDate;
        geolat=ageolat;
        geolong=ageolong;

    }
    public String getTitle()
    {
         return title;
    }
    public void setTitle(String atitle)
    {
        title = atitle;
    }
    public String getDescription()
    {
        return description;
    }
    public void  setDescription(String adescription)
    {
        description = adescription;
    }
    public String getLink()
    {
        return link;
    }
    public void setLink(String alink)
    {
        link = alink;
    }
    public String getpubDate()
    {
        return pubDate;
    }
    public void setpubDate(String apubDate)
    {
        pubDate= apubDate ;
    }
    public String getCategory()
    {
        return category;
    }
    public void setCategory(String acategory)
    {
        category = acategory;
    }
    public String getGeolat()
    {
        return geolat;
    }
    public void setGeolat(String ageolat)
    {
        geolat = ageolat;
    }
    public void setGeolong(String ageolong)
    {
        geolong = ageolong;
    }
    public String getGeolong()
    {
        return geolong;
    }
    public String toString()
    {
        String temp;
        temp = title + " "+ description+ " "+ pubDate+" "+ geolat+ " "+ geolong;
                return temp;
    }
}